import Reveal from 'reveal.js';
import 'reveal.js/reveal.css';
import './style.css';

const slides = [...document.querySelectorAll('.slides > section')];
slides.forEach((slide, index) => {
  const number = slide.querySelector('.page-number');
  if (number) number.textContent = String(index + 1);
});

const deck = new Reveal(document.querySelector('.reveal'), {
  width: 1440,
  height: 810,
  margin: 0.06,
  minScale: 0.1,
  maxScale: 1.5,
  transition: 'none',
  backgroundTransition: 'none',
  autoAnimate: false,
  fragments: false,
  autoSlide: false,
  center: false,
  controls: false,
  progress: false,
  hash: true,
  overview: false,
  view: 'slide',
});

const previous = document.querySelector('#previous');
const next = document.querySelector('#next');
const fullscreen = document.querySelector('#fullscreen');
const slideCount = document.querySelector('#slide-count');
function updateNavigation() {
  const index = deck.getIndices().h;
  slideCount.textContent = `${index + 1} / ${slides.length}`;
  previous.disabled = index === 0;
  next.disabled = index === slides.length - 1;
  document.title = `${slides[index].dataset.name} | AI駆動開発のセキュリティ統制`;
}
previous.addEventListener('click', () => deck.prev());
next.addEventListener('click', () => deck.next());
fullscreen.addEventListener('click', async () => {
  try {
    if (document.fullscreenElement) await document.exitFullscreen();
    else await document.documentElement.requestFullscreen();
  } catch {
    fullscreen.textContent = 'F11で全画面';
  }
});
document.addEventListener('fullscreenchange', () => {
  fullscreen.textContent = document.fullscreenElement ? '全画面を終了' : '全画面';
});
deck.on('slidechanged', updateNavigation);
await deck.initialize();
updateNavigation();
